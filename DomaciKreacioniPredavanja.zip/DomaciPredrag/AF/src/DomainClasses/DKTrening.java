/* DKTrening.java
 * @autor Predrag Imsic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 10.11.2019.
 */
package DomainClasses;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Home
 */
public class DKTrening implements Serializable, GeneralDObject {

    private int SifraTreninga;
    private String SifraPolaznika;
    private String VrstaTreninga;
    private int Trajanje;
    private String Napomena;
    private Date Datum;

    public DKTrening() {
        SifraTreninga = 0;
        SifraPolaznika = "000000";
        VrstaTreninga = "";
        Trajanje = 0;
        Napomena = "";
        SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
        Date dDatum = new Date();
        Datum = java.sql.Date.valueOf(sm.format(dDatum));
    }

    public DKTrening(int sifraTreninga, String sifraPolaznika, String vrstaTreninga, int trajanje, String napomena, Date datum) {
        this.SifraTreninga = sifraTreninga;
        this.SifraPolaznika = sifraPolaznika;
        this.VrstaTreninga = vrstaTreninga;
        this.Trajanje = trajanje;
        this.Napomena = napomena;
        this.Datum = datum;
    }

    public DKTrening(int SifraTreninga) {
        this.SifraTreninga = SifraTreninga;
    }

    public int getSifraTreninga() {
        return SifraTreninga;
    }

    public void setSifraTreninga(int SifraTreninga) {
        this.SifraTreninga = SifraTreninga;
    }

    public String getSifraPolaznika() {
        return SifraPolaznika;
    }

    public void setSifraPolaznika(String SifraPolaznika) {
        this.SifraPolaznika = SifraPolaznika;
    }

    public String getVrstaTreninga() {
        return VrstaTreninga;
    }

    public void setVrstaTreninga(String VrstaTreninga) {
        this.VrstaTreninga = VrstaTreninga;
    }

    public int getTrajanje() {
        return Trajanje;
    }

    public void setTrajanje(int Trajanje) {
        this.Trajanje = Trajanje;
    }

    public String getNapomena() {
        return Napomena;
    }

    public void setNapomena(String Napomena) {
        this.Napomena = Napomena;
    }

    public Date getDatum() {
        return Datum;
    }

    public void setDatum(Date Datum) {
        this.Datum = Datum;
    }

    @Override
    public String getAtrValue() {
        return SifraTreninga + ", " + (SifraPolaznika == null ? null : "'" + SifraPolaznika + "'") + ", "+"'" + VrstaTreninga + "'" + ", " + Trajanje + ", " + "'" + Napomena + "'" + ", " + "'" + Datum + "'";
    }

    @Override
    public String setAtrValue() {
        return "SifraTreninga=" + SifraTreninga + ", " + "SifraPolaznika=" + (SifraPolaznika == null ? null : "'" + SifraPolaznika + "'") + ", " + "VrstaTreninga=" + "'"+VrstaTreninga +"'"+ ", " + "Trajanje=" + Trajanje + ", " + "Napomena =" +"'"+ Napomena +"'"+ ", " + "Datum=" + "'" + Datum + "'";
    }

    @Override
    public String getClassName() {
        return "DKTrening";
    }

    @Override
    public String getWhereCondition() {
        return "SifraTreninga = " + SifraTreninga;
    }

    @Override
    public String getNameByColumn(int column) {
        {
            String names[] = {"SifraTreninga", "SifraPolaznika", "VrstaTreninga", "Trajanje", "Napomena", "Datum"};
            return names[column];
        }
    }

    @Override
    public GeneralDObject getNewRecord(ResultSet rs) throws SQLException {
        return new DKTrening(rs.getInt("SifraTreninga"), rs.getString("SifraPolaznika"),rs.getString("VrstaTreninga"), rs.getInt("Trajanje"),rs.getString("Napomena"), rs.getDate("Datum"));
    }

}
