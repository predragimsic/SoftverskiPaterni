/* Panel.java
 * @autor Predrag Imsic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Softverski paterni
 * 10.11.2019.
 */


package AbstractProductA;



import java.awt.event.KeyEvent;
import java.util.Date;

// Promenljivo!!!
public abstract class Panel extends javax.swing.JPanel{
       
       public abstract String getSifraTreninga(); // Promenljivo!!!
       public abstract javax.swing.JTextField getSifraTreninga1(); // Promenljivo!!!
       public abstract String getSifraPolaznika(); // Promenljivo!!
       public abstract String getVrstaTreninga(); // Promenljivo!!!
       public abstract String getTrajanje(); // Promenljivo!!!
       public abstract String getNapomena(); // Promenljivo!!!
       public abstract Date getDatum(); // Promenljivo!!!
       
       public abstract void setSifraTreninga(String SifraTreninga1); // Promenljivo!!!
       public abstract void setSifraPolaznika(String SifraPolaznika1); // Promenljivo!!
       public abstract void setVrstaTreninga(String VrstaTreninga); // Promenljivo!!!
       public abstract void setTrajanje(String Trajanje1); // Promenljivo!!!
       public abstract void setNapomena(String Napomena1); // Promenljivo!!!
       public abstract void setDatum(Date Datum); // Promenljivo!!!
       
       public abstract void setPoruka(String Poruka);
       
       public abstract javax.swing.JButton getKreiraj(); 
       public abstract javax.swing.JButton getPromeni(); 
       public abstract javax.swing.JButton getObrisi(); 
       public abstract javax.swing.JButton getNadji();
       public abstract javax.swing.JButton getTekuciLog();
       
       
       
}
